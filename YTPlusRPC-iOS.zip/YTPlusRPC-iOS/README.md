# YouTube Plus RPC for iOS

iOS port of [dayanch96/YTPlus-Discord-RPC](https://github.com/dayanch96/YTPlus-Discord-RPC).
It runs the same `POST /update` and `GET /health` server on port 5001 and sets your Discord presence through
the official Discord Social SDK (OAuth sign-in, no password handled by the app).

In YouTube Plus -> Discord RPC, set the server address to `http://127.0.0.1:5001` (same device)
or the address shown in the app.

## Build with GitHub Actions (unsigned IPA)

1. Create an application at https://discord.com/developers/applications and enable the Social SDK for it.
   Add the redirect URI `discord-<APPLICATION_ID>://authorize/callback` (check the SDK docs for the exact form).
2. Repo -> Settings -> Secrets and variables -> Actions:
   - Variable `DISCORD_CLIENT_ID` = your Application ID
   - Secret `DISCORD_SDK_URL` = direct URL to the Social SDK iOS zip you downloaded from the Discord developer portal
     (host it privately; do not commit it to a public repo, the SDK license restricts redistribution).
     Alternatively, put `discord_partner_sdk.xcframework` into `Frameworks/` in a private fork.
3. Run the **Build unsigned IPA** workflow and download the `YTPlusRPC-unsigned-ipa` artifact.
4. Install it through LiveContainer.

Without the SDK the project still builds, but with stubs: the server runs, nothing reaches Discord.

## Notes

- A silent audio loop keeps the app (and the port) alive in the background. Inside LiveContainer this depends on the host app's background modes.
- `Sources/Bridge/DiscordBridge.mm` is the only file that touches the SDK. It was written from the SDK's documented C++ API and has not been compiled against a real SDK build, so you may need to adjust a call or header name.
- Presence updates are skipped when nothing visible changed, to stay under Discord's rate limits.
